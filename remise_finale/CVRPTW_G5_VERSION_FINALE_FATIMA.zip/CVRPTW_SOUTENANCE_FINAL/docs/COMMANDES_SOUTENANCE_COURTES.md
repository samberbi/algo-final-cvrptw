# Quatre commandes pour la soutenance

Depuis le terminal PowerShell du dossier **algo soutenance**. L'environnement
est déjà préparé. Chaque commande ouvre automatiquement une page HTML avec
le tableau des résultats, les courbes de convergence et les cartes côte à côte.
Les labels déjà utilisés reçoivent un suffixe ; les résultats précédents restent conservés.

## 1. Petit cas lisible : 25 clients

Deux moteurs sur C101 : idéal pour montrer les tournées et expliquer les contraintes.

```powershell
.\.venv\Scripts\python.exe scripts/test_instances.py --instances C101 --size 25 --methods ils size_based --seconds 5 --label soutenance_petit
```

## 2. Trois structures à 100 clients

C204 : clients regroupés ; R109 : clients dispersés ; RC101 : structure mixte.
Six résolutions, cinq secondes demandées à chaque moteur. Le renforcé peut
améliorer, égaler ou dégrader le résultat ILS : lire les valeurs et les temps,
sans annoncer à l'avance un vainqueur.

```powershell
.\.venv\Scripts\python.exe scripts/test_instances.py --instances C204 R109 RC101 --methods ils size_based --seconds 5 --label soutenance_structures
```

## 3. ILS contre recuit simulé

Deux moteurs sur R201. Les coûts courants et les températures ne sont dessinés
que lorsqu'ils figurent effectivement dans les traces ; aucune courbe n'est inventée.

```powershell
.\.venv\Scripts\python.exe scripts/test_instances.py --instances R201 --methods ils sa --seconds 5 --label soutenance_recuit
```

## 4. Passage à 1 000 clients

Deux résolutions, trente secondes demandées par moteur : prévoir environ une
minute de recherche, plus préparation et démarrage. Cette démonstration courte
ne reproduit pas les budgets variables de l'archive complète.

```powershell
.\.venv\Scripts\python.exe scripts/test_instances.py --instances C2_10_7 --methods ils size_based --seconds 30 --label soutenance_grand
```

## Lire la page HTML

Le tableau en haut permet de chercher une instance, filtrer par taille, trier
chaque colonne et exporter le CSV. Cliquer sur une instance mène à ses figures.
Le coût est la durée complète, trajets + attentes + services, retour compris.
L'écart au témoin n'est pas un gap certifié à l'optimum temporel. Le gain du
renforcé est calculé par rapport à l'ILS du même cas et de la même graine.

Dans chaque dossier `results/local/<label>/` : `RESULTATS.html` et
`GRAPHIQUES.html` ouvrent la présentation ; `TABLEAU_RESULTATS.csv` exporte
les valeurs. Les PNG du dossier `figures` peuvent être ouverts en grand.
La génération des graphiques reste hors du temps de résolution.

Pour rouvrir un lot sans relancer les calculs, remplacer le label par celui
annoncé à la fin de la commande :

```powershell
.\.venv\Scripts\python.exe scripts/plot_terminal_results.py --label soutenance_petit --open
```
