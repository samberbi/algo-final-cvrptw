# Correction de l'environnement du PC de soutenance

Le premier passage sur la branche `rendu-professeur` a donné six erreurs
`ModuleNotFoundError: ortools` et un échec du test de partitionnement sous un
budget de 0,4 seconde.

Le comparateur OR-Tools est nécessaire aux tests `test_final_static.py`, même
lorsqu'on utilise ILS et PyVRP pour les démonstrations. OR-Tools 9.15 demande
NumPy 2, incompatible avec les binaires Anaconda installés sur ce poste.
L'environnement local utilise donc **OR-Tools 9.14.6206 et NumPy 1.26.4**.
Les autres moteurs et les résultats des campagnes déjà publiées sont conservés.
Le binaire PyArrow 16.1.0 provenant de PyPI est installé dans `.venv` :
celui d'Anaconda chargeait une DLL `re2` incompatible avec OR-Tools dans le
même processus. Les imports Pandas, PyArrow puis OR-Tools sont vérifiés ensemble.
Une résolution relancée sur ce PC n'est pas présentée comme une reproduction
exacte des mesures obtenues avec une autre version du comparateur.

Les dépendances compatibles sont dans `requirements-pc-soutenance.txt`.
Le test fonctionnel de partitionnement dispose de cinq secondes : il vérifie
toujours la faisabilité, le coût attendu et l'exécution ou la désactivation du
partitionnement. Ce budget évite de confondre un dépassement d'initialisation
sur un autre PC avec un défaut du partitionnement. Aucun budget de campagne
n'est changé par cette correction de test.

L'activation automatique du terminal est désactivée dans la configuration
locale VS Code. Aucune modification de la politique PowerShell n'est requise :

```powershell
.\.venv\Scripts\python.exe -m pip check
.\.venv\Scripts\python.exe -m pytest tests -q --junitxml=livraison/TESTS_SOUTENANCE.xml
.\.venv\Scripts\python.exe scripts/validate_soutenance.py
```

Les deux commandes de vérification sont à exécuter dans cet ordre : le
validateur du livrable refuse un XML contenant encore des tests en échec.
