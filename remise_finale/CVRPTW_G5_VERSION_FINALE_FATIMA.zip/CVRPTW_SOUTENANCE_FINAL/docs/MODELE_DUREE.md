## 3. Modélisation mathématique du CVRPTW en durée

Nous formalisons le **CVRPTW statique étudié ici** : un dépôt unique, des véhicules homogènes, des livraisons indivisibles, une tournée au plus par véhicule et des trajets fixes et symétriques. L'attente avant ouverture est autorisée. Le début du service doit appartenir à la fenêtre du client et le retour doit respecter la fermeture du dépôt. Les bornes sont inclusives. Le trafic variable, les ramassages, les dépôts multiples et les flottes hétérogènes ne font pas partie des expériences réalisées.

**Ensembles et indices.** Le nombre de clients est l'entier $n\ge1$. Leur ensemble est $C=\{1,\ldots,n\}$. Le nombre maximal de véhicules est l'entier $K\ge0$ et leur ensemble d'indices est $\mathcal K=\{1,\ldots,K\}$. Ainsi, $n$ et $K$ sont des nombres ; $C$ et $\mathcal K$ sont des ensembles. L'écriture $\forall i\in C$ signifie « pour chaque client i appartenant à C ». Elle ne désigne pas une boucle « tant que ».

Nous représentons le dépôt physique par deux sommets : $o$ pour le départ et $r$ pour le retour. Cette duplication permet de distinguer les heures de départ et de retour ; elle n'ajoute pas un deuxième dépôt réel. Les sommets et arcs autorisés sont :

$$V=C\cup\{o,r\},$$
$$A=(\{o\}\times C)\cup\{(i,j)\in C\times C:i\ne j\}\cup(C\times\{r\}).$$

Les véhicules peuvent aller du départ à un client, entre deux clients distincts, puis d'un client au retour. Aucune boucle sur un même sommet n'est autorisée. Aucun arc n'entre dans o et aucun arc ne quitte r.

**Des fenêtres par objet aux fenêtres par client.** Les benchmarks fournissent une demande et une fenêtre par client, sans détail des objets. Nous interprétons donc un client comme une livraison agrégée effectuée en un seul passage. Si les objets $a\in O_i$ ont des demandes $q_a$ et doivent partager un même début de livraison chez i, l'agrégation serait $q_i=\sum_{a\in O_i}q_a$, $e_i=\max_{a\in O_i}e_a$ et $l_i=\min_{a\in O_i}l_a$. Une intersection vide rendrait cette livraison commune impossible. Des objets livrés à des horaires différents ou plusieurs visites au même client demanderaient un autre modèle ; nous ne prétendons pas traiter ce cas avec les données agrégées actuelles.

**Paramètres.** Pour chaque client $i\in C$, soient $q_i,s_i,e_i,l_i\in\mathbb R_{\ge0}$ : sa demande est $q_i$, sa durée de service $s_i$ et sa fenêtre de début de service $[e_i,l_i]$. Soient $Q,H\in\mathbb R_{>0}$ la capacité commune et la fermeture du dépôt. Comme dans les données acceptées par `Instance`, nous supposons $0\le e_i\le l_i\le H$ pour tout $i\in C$. Pour chaque arc $(i,j)\in A$, soient $d_{ij},c_{ij}\in\mathbb R_{\ge0}$ sa distance et son temps de trajet. Les départs sont fixés au temps zéro. Dans les benchmarks du projet, temps de trajet et distances ont les mêmes valeurs numériques ; le modèle distingue néanmoins leurs rôles et leurs unités.

**Pourquoi fixer le départ à zéro ?** Nous supposons que le temps mobilisé de chaque véhicule utilisé est compté depuis une même origine, l'ouverture du dépôt. Cette convention simplifie les horaires et aligne le PLNE, notre contrôleur et PyVRP ; ce n'est pas une obligation générale du CVRPTW et correspond au périmètre professoral confirmé pour cette finalisation. Si les départs $D_k$ devenaient des décisions libres, il faudrait minimiser $\sum_k(R_k-D_k)$ et adapter les contraintes de départ ainsi que l'évaluation de tous les témoins. Retarder le départ peut éviter une attente sur tournée : les pourcentages des deux conventions ne seraient donc pas interchangeables. Cette extension n'est pas implémentée dans les expériences présentées.

**Variables de décision et domaines.**

$$x_{ij}^k\in\{0,1\}\quad\forall(i,j)\in A,\ \forall k\in\mathcal K.$$

Pour chaque arc et chaque véhicule, x vaut un si le véhicule emprunte cet arc, et zéro sinon.

$$y_i^k\in\{0,1\}\quad\forall i\in C,\ \forall k\in\mathcal K,\qquad
u_k\in\{0,1\}\quad\forall k\in\mathcal K.$$

La variable y vaut un si le client i est affecté au véhicule k. La variable u vaut un si le véhicule k est utilisé.

$$t_i\in\mathbb R_{\ge0}\quad\forall i\in C,\qquad
R_k\in\mathbb R_{\ge0}\quad\forall k\in\mathcal K.$$

La variable t est l'heure de **début du service**, pas l'heure d'arrivée. La variable R est l'heure de retour au dépôt. Les bornes horaires sont imposées ci-dessous.

Enfin, $f_{ij}^k\in\mathbb R_{\ge0}$, pour chaque $(i,j)\in A$ et chaque $k\in\mathcal K$, est un flot artificiel assurant la connexion au dépôt. Il représente un outil mathématique, pas la marchandise dans le camion.

### 3.1. Fonction objectif : minimiser la durée totale

$$\boxed{\min T=\sum_{k\in\mathcal K}R_k}.$$

Chaque véhicule part à zéro. $R_k$ est donc sa durée de tournée, retour au dépôt compris ; $R_k=0$ s’il n’est pas utilisé. Nous minimisons la somme des temps mobilisés, et non le retour du dernier véhicule $\max_kR_k$ ni le temps de calcul du programme.

Pour une solution réalisable, cette durée se décompose en :

$$T=\sum_{k\in\mathcal K}\sum_{(i,j)\in A}c_{ij}x_{ij}^k+\sum_{i\in C}s_i+\sum_{i\in C}w_i,$$

où $w_i$ est l’attente avant le début du service, calculée à partir des horaires. La somme des services est constante pour une instance : elle est comptée mais ne constitue pas un gain que l’algorithme peut supprimer. Trajets et attentes peuvent varier. Les véhicules restent limités par la flotte disponible, sans priorité lexicographique ni coût fixe ajouté.

### 3.1.1. Équivalence avec la fonction objectif pondérant l’attente

La formulation à coûts d’arcs de la section 2.1 d’[El-Sherbeny (2010)](https://jksus.org/vehicle-routing-with-time-windows-an-overview-of-exact-heuristic-and-metaheuristic-methods/) peut être complétée par un terme d’attente. La formule pondérée examinée ici s’écrit, avec nos notations :

$$\boxed{\min Z_\beta=
\sum_{k=1}^{K}\sum_{i\in V}\sum_{j\in V}c_{ij}x_{ij}^{k}
+\beta\sum_{k=1}^{K}\sum_{i\in V}w_i^{k}.}$$

Le premier terme représente les trajets ; le second valorise l’attente avec le coefficient $\beta$. La pondération est une extension de la somme de coûts d’arcs : elle n’est pas attribuée à l’équation originale de l’article.

**Correspondance des symboles.** L’ensemble $V=C\cup\{o,r\}$ contient les clients et les deux copies du dépôt ; les véhicules sont indexés par $k\in\mathcal K=\{1,\ldots,K\}$. Pour les sommes sur tous les couples de sommets, on pose $x_{ij}^k=0$ si $(i,j)\notin A$. Pour chaque client $i\in C$ et chaque véhicule $k\in\mathcal K$, $w_i^k\ge0$ est l’attente chez i si k le visite, et vaut zéro sinon. Les attentes aux dépôts virtuels sont fixées à zéro. Il ne s’agit pas de remplacer les contraintes du PLNE par des pénalités.

Si $a_i^k$ désigne l’arrivée calculée à partir de la visite précédente, alors $w_i^k=t_i-a_i^k\ge0$ pour le véhicule affecté. Le contrôleur calcule le début au plus tôt $t_i=\max(a_i^k,e_i)$, soit $w_i^k=\max(0,e_i-a_i^k)$. Comme chaque client est visité exactement une fois :

$$w_i=\sum_{k\in\mathcal K}w_i^k\qquad\forall i\in C.$$

**Conditions de l’équivalence.** Dans cette comparaison, $c_{ij}$ doit représenter le temps de trajet, avec les mêmes unités que l’attente et le service, et le poids de l’attente doit être $\beta=1$. Les véhicules partent à zéro et les services sont fixes, obligatoires et effectués une fois par client. Une distance ou un coût monétaire ne peut pas être additionné à un temps sans conversion. Dans nos benchmarks, distances et temps de trajet ont les mêmes valeurs numériques ; leurs significations restent distinctes.

Notons le total constant des services :

$$S=\sum_{i\in C}s_i.$$

Pour $\beta=1$, la formule pondérée et notre objectif sont liés par :

$$Z_1=\underbrace{\sum_{k\in\mathcal K}\sum_{(i,j)\in A}c_{ij}x_{ij}^{k}}_{\text{trajets}}
+\underbrace{\sum_{k\in\mathcal K}\sum_{i\in C}w_i^{k}}_{\text{attentes}},$$
$$\boxed{T=\sum_{k\in\mathcal K}R_k=Z_1+S.}$$

**Démonstration.** Soit $C_k\subseteq C$ l’ensemble des clients servis par le véhicule k. Puisque son départ est fixé à zéro, sa durée opérationnelle est :

$$R_k=\sum_{(i,j)\in A}c_{ij}x_{ij}^{k}+\sum_{i\in C_k}s_i+\sum_{i\in C_k}w_i^k
\qquad\forall k\in\mathcal K.$$

Pour un véhicule inutilisé, les trois contributions valent zéro. En sommant sur les véhicules et en utilisant la visite unique, on retrouve $\sum_kR_k=Z_1+S$. Dans le PLNE, les bornes de retour C7 sont serrées à l’optimum par la minimisation : augmenter artificiellement $R_k$ ne présente aucun intérêt.

Soit $\mathcal F$ l’ensemble commun des solutions réalisables, soumises aux mêmes capacités, fenêtres et départs. Comme S est constant pour une instance :

$$\boxed{\operatorname*{arg\,min}_{\mathcal F}T
=\operatorname*{arg\,min}_{\mathcal F}(Z_1+S)
=\operatorname*{arg\,min}_{\mathcal F}Z_1.}$$

**Conclusion mathématique.** Les deux fonctions sont équivalentes pour choisir les meilleures solutions lorsque $\beta=1$ et sous les conventions précédentes. Leurs valeurs numériques diffèrent de S. Si l’on ajoute explicitement les services à la formule pondérée, on obtient exactement la même valeur que notre durée totale. Pour $\beta\ne1$, les priorités entre conduite et attente changent : cette équivalence n’est pas garantie. Pour $\beta=0$, l’attente est ignorée.

**Exemple vérifiable dans le livrable.**

| Ordre de visite | Trajets | Attente | Services S | Formule pondérée $Z_1$ | Notre durée $T=Z_1+S$ |
| --- | --- | --- | --- | --- | --- |
| $0\to1\to2\to0$ | 18 | 7 | 9 | 25 | 34 |
| $0\to2\to1\to0$ | 18 | 1 | 9 | 19 | 28 |

Les deux objectifs préfèrent le deuxième ordre ; ils donnent tous deux une amélioration absolue de six unités. Le service ajoute neuf unités aux deux valeurs et ne change pas le classement. Le seul total des trajets, égal à 18 dans les deux cas, ne les départage pas.

**Conséquences pour les statistiques.** L’ajout d’une constante conserve le classement et les différences absolues, mais pas les pourcentages relatifs. Le gain depuis 34 vers 28 est $100(34-28)/34$, soit environ 17,65 %, tandis que celui depuis 25 vers 19 vaut $100(25-19)/25=24\,\%$. Les pourcentages publiés restent donc calculés en durée totale T, sans les renommer comme des pourcentages sur $Z_1$. Les témoins sont évalués avec la même convention que les solutions comparées. L’équivalence des objectifs ne garantit pas non plus une trajectoire de recherche identique si l’on modifie des seuils relatifs ou une température dépendant du coût initial.

**Lien avec le code.** `algo/duration_kernels.py::route_eval` calcule déjà $T=Z_1+S$ : le `max` compte l’attente, `service[client]` ajoute le service, et le retour au dépôt ajoute le dernier trajet. Les mouvements, les acceptations et l’archive sont évalués avec cette durée complète. Le code est ainsi cohérent avec notre PLNE et avec la formule pondérée à $\beta=1$, au sens de l’optimisation démontré ci-dessus. Il ne prétend pas traiter un $\beta$ arbitraire. Capacité, fenêtres et fermeture du dépôt restent strictement obligatoires.

### 3.2. Contraintes et lecture opérationnelle

**C1 — Affecter chaque client exactement une fois.**

$$\sum_{k\in\mathcal K}y_i^k=1\qquad\forall i\in C.$$

Pour chaque client i, la somme des affectations vaut un : un seul véhicule réalise l'intégralité de sa livraison. Aucun client ne peut être oublié ou réparti entre plusieurs camions.

**C2 — Assurer une entrée et une sortie avec le véhicule affecté.**

$$\sum_{j:(j,i)\in A}x_{ji}^k=y_i^k,
\qquad\sum_{j:(i,j)\in A}x_{ij}^k=y_i^k
\qquad\forall i\in C,\ \forall k\in\mathcal K.$$

Pour chaque client et chaque véhicule, une affectation impose exactement une entrée et une sortie. Sans affectation, ce véhicule n'emprunte aucun arc entrant ou sortant de ce client. Les indices des sommes sont limités aux arcs autorisés de A.

**C3 — Partir du dépôt et y revenir, au plus une fois par véhicule.**

$$\sum_{j\in C}x_{oj}^k=u_k,
\qquad\sum_{i\in C}x_{ir}^k=u_k
\qquad\forall k\in\mathcal K.$$

Chaque véhicule utilisé effectue un départ et un retour. Un véhicule inutilisé n'en effectue aucun. On autorise donc l'utilisation de moins de K camions. La borne $\sum_{k\in\mathcal K}u_k\le K$ est automatiquement satisfaite, puisque u est binaire et que $\mathcal K$ contient K véhicules.

**C4 — Respecter la capacité de chaque camion.**

$$\sum_{i\in C}q_iy_i^k\le Qu_k
\qquad\forall k\in\mathcal K.$$

Pour chaque véhicule, la somme des quantités affectées ne dépasse pas Q. Cette somme est la charge à emporter au départ pour des livraisons pures. Elle diminue ensuite pendant la tournée ; il n'y a aucun ramassage. Le code peut donc contrôler la même contrainte en additionnant les demandes de la tournée. Les unités de demande ne sont pas multipliées par dix.

**C5 — Commencer le service dans la fenêtre du client.**

$$e_i\le t_i\le l_i\qquad\forall i\in C.$$

Pour chaque client, le début du service se situe entre ouverture et fermeture, bornes comprises. Une arrivée avant l'ouverture est possible avec attente. La fin $t_i+s_i$ peut dépasser $l_i$ : notre projet n'impose pas une fenêtre sur la fin du service.

**C6 — Respecter l'ordre temporel des trajets et services.**

Posons $s_{\max}=\max_{i\in C}s_i$, $c_{\max}=\max_{(i,j)\in A}c_{ij}$ et $M=H+s_{\max}+c_{\max}$. Cette borne est valide sous les hypothèses d'horizon précédentes.

$$t_j\ge c_{oj}-M(1-x_{oj}^k)
\qquad\forall j\in C,\ \forall k\in\mathcal K.$$

Pour chaque client j et chaque véhicule k, si l'arc du dépôt vers j est utilisé, le service ne commence pas avant la fin du trajet depuis le départ au temps zéro.

$$t_j\ge t_i+s_i+c_{ij}-M(1-x_{ij}^k)
\qquad\forall i,j\in C,\ i\ne j,\ \forall k\in\mathcal K.$$

Pour chaque paire de clients distincts et chaque véhicule, emprunter l'arc de i vers j impose de terminer le service chez i puis le trajet avant de commencer chez j. Si cet arc n'est pas utilisé, M désactive l'implication. Une borne par arc pourrait renforcer une résolution exacte sans changer les règles métier.

Les contraintes imposent des horaires réalisables ; minimiser la somme des retours sélectionne une durée minimale pour les tournées retenues. Une fois l'ordre fixé, `verify()` recalcule les horaires au plus tôt : arrivée = fin précédente + trajet ; début = maximum entre arrivée et ouverture ; fin = début + service.

**C7 — Relier le retour à la tournée et respecter la fermeture du dépôt.**

$$R_k\ge t_i+s_i+c_{ir}-M(1-x_{ir}^k)
\qquad\forall i\in C,\ \forall k\in\mathcal K,$$
$$0\le R_k\le Hu_k\qquad\forall k\in\mathcal K.$$

Si le véhicule k revient directement du client i, alors $x_{ir}^k=1$ : la première inégalité impose de terminer le service puis le trajet de retour avant $R_k$. La seconde impose la fermeture du dépôt et fixe $R_k=0$ pour un véhicule inutilisé. Un retour exactement à H est autorisé.

**Pourquoi simplifier cette contrainte ?** Dans la version précédente, nous écrivions aussi $R_k\le t_i+s_i+c_{ir}+M(1-x_{ir}^k)$. Cette borne supérieure supplémentaire est redondante à l'optimum pour notre objectif $\min\sum_k R_k$ : la minimisation choisit déjà la plus petite valeur permise par la borne inférieure. Nous la retirons de la formulation en durée et du solveur exact correspondant. Cela conserve l'objectif optimal et les tournées réalisables, sans imposer une égalité à tous les horaires non optimaux. Le mode historique en distance conserve cette égalité explicite, car son objectif ne minimise pas les retours.

**Exemple.** Si le dernier service commence à 50, dure 10 et est suivi de 5 unités de trajet, alors $R_k\ge65$ ; la minimisation donne 65. Si le dépôt ferme à 60, cette tournée est interdite. Supprimer tout C7 serait donc incorrect : $R_k$ ne serait plus relié au trajet de retour et pourrait artificiellement valoir zéro. Nous retirons donc uniquement la borne supérieure redondante ; le retour avant fermeture reste obligatoire. Les dix petits cas de contrôle conservent leur optimum après cette simplification.

**C8 — Interdire les cycles de clients isolés du dépôt.**

$$0\le f_{ij}^k\le nx_{ij}^k
\qquad\forall(i,j)\in A,\ \forall k\in\mathcal K,$$
$$f_{ir}^k=0\qquad\forall i\in C,\ \forall k\in\mathcal K.$$

Le flot artificiel ne passe que sur un arc utilisé. Il fournit une unité par client et n'a plus rien à transporter lors du retour au dépôt.

$$\sum_{j:(j,i)\in A}f_{ji}^k-\sum_{j:(i,j)\in A}f_{ij}^k=y_i^k
\qquad\forall i\in C,\ \forall k\in\mathcal K,$$
$$\sum_{j\in C}f_{oj}^k=\sum_{i\in C}y_i^k
\qquad\forall k\in\mathcal K.$$

Chaque client affecté consomme une unité reçue du dépôt. Le dépôt en émet autant que de clients affectés au véhicule. Un cycle isolé ne peut pas satisfaire cette consommation : en additionnant les équations de ses clients, tous les flots internes s'annulent alors qu'une consommation strictement positive resterait nécessaire. Le flot empêche ainsi les sous-tournées, même lorsque des temps tronqués sont nuls.

**Convention numérique et représentation dans le programme.** Les références DIMACS utilisent chaque arc euclidien tronqué à une décimale. `algo/data.py` calcule sa valeur entière à l'échelle dix et multiplie fenêtres et services par dix. Les coûts affichés sont reconvertis. Les dépôts o et r du PLNE correspondent tous deux à l'indice 0 du code ; les retours sont ajoutés implicitement aux listes de tournées. Les contraintes restent obligatoires, quelle que soit la métaheuristique choisie.



**Pourquoi le grand M est valide.** Les bornes $0\le t_i,t_j\le H$ impliquent $t_i+s_i+c_{ij}-t_j\le H+s_{\max}+c_{\max}$. Cette valeur désactive donc la propagation d'un arc non utilisé. Des bornes par arc peuvent renforcer le solveur exact sans modifier les solutions autorisées. Le modèle contient de l'ordre de $Kn^2$ variables d'arcs/flots et contraintes : l'exact sert ici aux petits cas.
