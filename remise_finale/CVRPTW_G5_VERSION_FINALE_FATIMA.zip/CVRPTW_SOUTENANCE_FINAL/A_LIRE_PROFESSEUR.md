# Remise finale — Groupe G5 — CVRPTW

**Anes AMARI - Youcef HADJ AISSA - Axel CHEBAHI - Ramy HAMOUR - Samy BARBICHE**

Extraire le ZIP complet avant d'ouvrir les documents ou de lancer les commandes.
Les images et données sont fournies avec leurs chemins relatifs.

## Lire le livrable actuel

- **Version à consulter :** [livrable HTML](notebooks/Livrable_Final_CVRPTW.html), lisible dans un navigateur sans exécuter Python.
- **Notebook exécuté :** [Livrable_Final_CVRPTW.ipynb](notebooks/Livrable_Final_CVRPTW.ipynb), avec code et sorties conservées.
- [Texte Markdown](LIVRABLE_FINAL.md), avec modélisation, méthodes, statistiques, schémas et explications.
- Les anciens fichiers `livraison/RAPPORT_CVRPTW.pdf`, `.docx`, `.html` et `.md` sont conservés pour l'historique. Ils ne remplacent pas le notebook et son HTML actuels.

L'objectif actuel est la somme des durées des tournées : trajets, attentes et services, retours au dépôt compris, avec départs à zéro. Les plans publics optimisent historiquement la distance : leur réévaluation en durée fournit des témoins réalisables, sans certification d'optimalité temporelle.

## Code et expériences

- `algo/` : données, construction, ILS, recuit, mouvements, adaptateurs PyVRP et vérificateur indépendant. Des commentaires pédagogiques expliquent le parcours principal.
- `controle/` : PLNE complet pour petits cas et oracle exhaustif de contrôle.
- `scripts/` : campagnes, analyses, vérifications et rapports HTML.
- `tests/` : suite de tests automatisés.
- `data/` : instances, solutions témoins et manifestes de provenance.
- `results/` : mesures individuelles, protocoles, sources figées et résultats historiques.
- `results/local/soutenance_*/GRAPHIQUES.html` : démonstrations locales avec tableaux, convergence, ligne du plan témoin et cartes des tournées.
- `web/` : interface de simulation des tournées et tableaux de contraintes.
- `livraison/` : figures, tableaux et comptes rendus de validation.

Les sources figées dans les anciennes campagnes sont conservées : elles identifient le code ayant produit ces mesures. Les ajouts de commentaires et d'affichage ne sont pas présentés comme une nouvelle campagne d'optimisation.

## Installer sur un autre ordinateur

Python **3.12 en 64 bits** est requis pour la configuration fournie. Depuis la racine du dossier extrait, dans PowerShell :

```powershell
py -3.12 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements-pc-soutenance.txt
.\.venv\Scripts\python.exe -m pip check
```

Il n'est pas nécessaire d'activer l'environnement PowerShell. Une connexion Internet est nécessaire à l'installation des dépendances. Les environnements Python, les caches et les installateurs de dépendances ne sont pas inclus dans la remise.

## Vérifier et démontrer

```powershell
# Tests automatisés.
.\.venv\Scripts\python.exe -m pytest tests -q

# Vérification du livrable et des résultats enregistrés, sans relancer toutes les recherches.
.\.venv\Scripts\python.exe scripts/validate_soutenance.py

# Petite démonstration : ILS et profil renforcé, 25 clients.
.\.venv\Scripts\python.exe scripts/test_instances.py --instances C101 --size 25 --methods ils size_based --seconds 5 --label demonstration_professeur

# Comparaison ILS / recuit, avec température réellement enregistrée.
.\.venv\Scripts\python.exe scripts/test_instances.py --instances R201 --methods ils sa --seconds 5 --label demonstration_recuit

# Interface web de simulation.
.\.venv\Scripts\python.exe -m streamlit run web/app.py
```

Les commandes de démonstration produisent des tableaux et figures, puis ouvrent Chrome s'il est installé. Si un label existe déjà, un nouveau dossier est créé pour conserver les essais précédents. Le premier lancement peut prendre plus de temps en raison de la compilation Numba. Les durées et le nombre de mouvements peuvent varier selon la machine.

Les deux fichiers de tests optionnels liés à l'extension temporelle MAMUT peuvent être ignorés quand cette dépendance n'est pas installée ; cette extension est distincte du CVRPTW statique principal.

## Traçabilité de la remise

- `livraison/TESTS_SOUTENANCE.xml` : résultat de la suite exécutée avant la création du ZIP.
- `livraison/VALIDATION_SOUTENANCE.json` : contrôle des instances, du notebook et des résultats archivés.
- `CONTENU_ARCHIVE.json` : liste des fichiers du ZIP avec taille et empreinte SHA-256, générée lors de l'archivage.

Le ZIP contient les modifications locales actuelles, en plus de la version Git de départ. Les anciennes empreintes de campagnes décrivent leurs propres sources figées ; le manifeste de cette archive décrit les fichiers effectivement remis.
