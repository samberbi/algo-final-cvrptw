"""Constructions multiples et intensification externe en durée, sans référence.

Prototype distinct du moteur de la campagne initiale. Les recherches locales
proviennent de PyVRP 0.12.2 ; les constructions, leur orchestration et la
validation sont celles du projet. Aucun plan BKS n'entre dans la recherche.
"""
import importlib
import math
import time
import numpy as np
from .iterated import arrays, decode
from .savings import savings_construct
from .sequential import sequential_insert
from .verify import verify
from .route_pool import RoutePool


# ADAPTATEUR EXTERNE : les opérateurs de recherche locale viennent de PyVRP.
# Notre code prépare les données, orchestre les appels et vérifie leurs sorties.
class DurationLocalSearch:
    """Réutilise les données natives ; change seulement le voisinage à explorer."""
    def __init__(self, ins, seed):
        import pyvrp
        self.ins = ins
        self.pyvrp = pyvrp
        self.api = importlib.import_module('pyvrp.solve')
        values = [ins.travel, ins.distance, ins.demand, ins.service, ins.early, ins.late]
        if any(not np.array_equal(a, np.rint(a)) for a in values):
            raise ValueError('Exact integer data required; no rounding allowed')
        if ins.capacity != int(ins.capacity) or ins.horizon != int(ins.horizon) or ins.early[0] != 0:
            raise ValueError('Integer capacity/horizon and zero depot opening required')
        # Créer les clients PyVRP avec les mêmes demandes, services et fenêtres,
        # sans nouvel arrondi qui changerait l’instance comparée.
        clients = [pyvrp.Client(float(ins.xy[i,0]), float(ins.xy[i,1]),
                   delivery=[int(ins.demand[i])], service_duration=int(ins.service[i]),
                   tw_early=int(ins.early[i]), tw_late=int(ins.late[i])) for i in range(1,ins.n+1)]
        self.data = pyvrp.ProblemData(clients,
            [pyvrp.Depot(float(ins.xy[0,0]),float(ins.xy[0,1]),tw_early=0,tw_late=int(ins.horizon))],
            [pyvrp.VehicleType(num_available=ins.vehicles,capacity=[int(ins.capacity)],
                tw_early=0,tw_late=int(ins.horizon),start_late=0,
                # Objectif natif : zéro coût fixe et zéro coût distance ; seule la durée compte.
                # start_late=0 impose le départ à zéro pour inclure toutes les attentes.
                fixed_cost=0,unit_distance_cost=0,unit_duration_cost=1)],
            [ins.distance.astype(np.int64)],[ins.travel.astype(np.int64)])
        params = pyvrp.SolveParams()
        # Les données sont immuables : un ordre de proximité calculé pour cette
        # instance peut être réutilisé pendant toute la recherche. Le préfixe
        # d'un tri stable fournit exactement les mêmes voisins pour un k réduit.
        self._ordered_neighbors = None
        self._neighbor_cache = {}
        self.local = self.api.LocalSearch(self.data,pyvrp.RandomNumberGenerator(seed),self.neighbors(40))
        self._current_neighbor_count = min(40, ins.n-1)
        # Enregistrer les opérateurs compatibles de PyVRP. Leur implémentation
        # est externe ; l’orchestration et la vérification appartiennent au projet.
        for operator in params.node_ops:
            if operator.supports(self.data):self.local.add_node_operator(operator(self.data))
        for operator in params.route_ops:
            if operator.supports(self.data):self.local.add_route_operator(operator(self.data))
        # Toute durée réalisable est <= n*H, puisque chaque tournée non vide
        # contient un client. Une violation entière coûte davantage que ce total.
        penalty = float(ins.n*ins.horizon+1)
        self.evaluator = pyvrp.CostEvaluator([penalty],penalty,penalty)

    def neighbors(self, count):
        from pyvrp.search import NeighbourhoodParams
        if type(count) is not int or count < 1:
            raise ValueError('Positive integer neighbourhood required')
        # Un client ne peut avoir plus de n-1 autres clients voisins.
        # Un réglage nominal 120 donne donc au plus 99 voisins si n=100.
        effective = min(count, self.ins.n-1)
        if self._ordered_neighbors is None or self._ordered_width < effective:
            width = max(120, count)
            self._ordered_neighbors = self.api.compute_neighbours(
                self.data, NeighbourhoodParams(num_neighbours=width))
            self._ordered_width = min(width, self.ins.n-1)
            self._neighbor_cache.clear()
        if effective not in self._neighbor_cache:
            self._neighbor_cache[effective] = [row[:effective] for row in self._ordered_neighbors]
        return self._neighbor_cache[effective]

    def improve(self, routes, neighbors=40):
        # Avant/après : exiger une solution complète réalisable, puis refuser
        # une sortie invalide ou plus longue que l’entrée.
        before = verify(routes,self.ins)
        if not before['valid']:raise ValueError('Feasible complete solution required')
        effective = min(neighbors, self.ins.n-1)
        selected_neighbors = self.neighbors(neighbors)
        if effective != self._current_neighbor_count:
            self.local.neighbours = selected_neighbors
            self._current_neighbor_count = effective
        native = self.local(self.pyvrp.Solution(self.data,routes),self.evaluator)
        result = [list(map(int,r.visits())) for r in native.routes()]
        checked = verify(result,self.ins)
        if not checked['valid'] or checked['duration'] > before['duration']+1e-7:
            raise AssertionError('Native local search did not preserve feasible duration archive')
        assert all(r.start_time()==0 for r in native.routes())
        assert abs(sum(r.duration() for r in native.routes())-checked['duration'])<1e-7
        return result,checked['duration']


def solve(ins, seed=4101, seconds=10., restarts=4):
    """Recherche à limite souple : un appel natif commencé n'est pas interrompu.

    Toutes les durées de construction/préparation/recombinaison sont mesurées.
    Le résultat expose le dépassement éventuel, sans inventer un temps plafonné.
    """
    if not math.isfinite(seconds) or seconds<=0 or restarts<1:
        raise ValueError('Positive budget and restart count required')
    started = time.perf_counter()
    local = DurationLocalSearch(ins,seed)
    # Le réservoir conserve des tournées réalisables trouvées par plusieurs
    # constructions afin de pouvoir en recombiner les meilleures combinaisons.
    pool = RoutePool(ins,objective='duration')
    trace=[]
    cutoff=max(.1,seconds-1.)
    for restart in range(restarts):
        trial_seed = seed+10007*restart
        # Diversifier les départs : fusions Clarke-Wright et insertion séquentielle.
        # Ces constructeurs sont des heuristiques initiales, pas des phases ALNS.
        for method in ['savings','sequential']:
            if time.perf_counter()-started >= cutoff:break
            matrix,lengths,ok = (savings_construct(*arrays(ins),ins.vehicles,trial_seed,0. if restart==0 else .08)
                if method=='savings' else sequential_insert(*arrays(ins),ins.vehicles,trial_seed,1.,.5,0))
            if not ok:
                trace.append(dict(restart=restart,constructor=method,status='construction_failed'))
                continue
            routes,value = local.improve(decode(matrix,lengths),40)
            # Ajouter au réservoir la solution améliorée par la recherche locale.
            # Le meilleur plan complet reste disponible même sans recombinaison.
            pool.add_solution(routes)
            trace.append(dict(elapsed_s=time.perf_counter()-started,restart=restart,
                              constructor=method,best=pool.best_cost/10))
        if pool.best_routes is None:continue
        for neighbors in [60,80,120]:
            if time.perf_counter()-started >= cutoff:break
            routes,value = local.improve(pool.best_routes,neighbors)
            pool.add_solution(routes)
            trace.append(dict(elapsed_s=time.perf_counter()-started,neighbors=neighbors,best=pool.best_cost/10))
    if pool.best_routes is None:
        return dict(status='not_found',routes=None,runtime_s=time.perf_counter()-started,trace=trace)
    remaining=seconds-(time.perf_counter()-started)
    recombination=None
    if remaining>.1:
        # Le PLNE de partitionnement choisit parmi les tournées déjà observées.
        # Il ne résout pas le PLNE complet du CVRPTW sur tous les arcs.
        recombination=pool.recombine(min(1.,remaining),relative_gap=0.)
    routes=pool.best_routes
    if time.perf_counter()-started<seconds:
        routes,value=local.improve(routes,120)
    checked=verify(routes,ins)
    assert checked['valid']
    # Publier le temps réellement mesuré et le dépassement éventuel.
    # Un appel natif en cours peut finir après la limite souple demandée.
    elapsed=time.perf_counter()-started
    return dict(status='feasible',objective='duration',routes=routes,cost=checked['duration']/10,
                runtime_s=elapsed,requested_total_s=seconds,overrun_s=max(0.,elapsed-seconds),
                metrics=checked,trace=trace,pool_columns=len(pool.columns),recombination=recombination,
                attribution='Own constructions/orchestration/set partitioning; external PyVRP 0.12.2 local search')
