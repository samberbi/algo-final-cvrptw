"""Évaluation compilée de la durée : trajets, attentes et services, départ à 0."""
# Numba compile la boucle pour accélérer les très nombreux tests de mouvements.
# Le contrôle indépendant final reste implémenté en Python dans verify.py.
from numba import njit


@njit(cache=True)
def route_eval(seq, length, travel, distance, demand, service, early, late, capacity, horizon):
    """Renvoie faisabilité, durée de la tournée et charge, en unités internes.

    distance conserve la signature commune des mouvements ; elle n'entre pas
    dans le coût. Le retour au dépôt et toutes les attentes sont comptabilisés.
    """
    # seq contient les clients ; length indique combien de cases lire.
    # Le dépôt 0 est implicite au départ et au retour.
    clock = load = 0.0
    previous = 0
    for pos in range(length):
        client = seq[pos]
        load += demand[client]
        # Arrivée = fin du service précédent + trajet. Si le client ouvre plus tard,
        # on attend ; cette attente augmente bien le coût en durée.
        clock = max(clock + travel[previous, client], early[client])
        # Rejet immédiat si le début de service dépasse b_i ou si la charge dépasse Q.
        # Un mouvement moins cher reste interdit s’il viole une de ces contraintes.
        if clock > late[client] + 1e-8 or load > capacity + 1e-8:
            return False, 0.0, load
        clock += service[client]
        previous = client
    if length:
        clock += travel[previous, 0]
    # Le retour au dépôt doit se faire au plus tard à H. Le coût renvoyé est
    # la durée, et non la distance géométrique de la tournée.
    return clock <= horizon + 1e-8, clock, load
