"""API publique : minimisation de la durée cumulée des tournées."""
# Point d’entrée public du moteur en durée : les implémentations sont
# réexportées depuis duration.py ; il n’y a pas un autre algorithme caché ici.
from .duration import Settings,solve,construct,warmup
from .iterated import arrays,encode,decode


def production_settings(method='hybrid',**overrides):
    """Configure le moteur en durée ; les variantes distance restent explicites."""
    # Les paramètres explicitement fournis remplacent les valeurs par défaut.
    # La validation de Settings rejette les budgets ou méthodes invalides.
    return Settings(method=method,**overrides)
